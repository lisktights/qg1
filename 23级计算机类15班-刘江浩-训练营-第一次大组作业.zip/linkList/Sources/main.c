#include <stdio.h>
#include <stdlib.h>
#include"LinkList.h"
#include"menu.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	
	int choice=0;
	char c;
	int oldval=0;int newval=0;
	int delValue=0;
	
	while(1){
			printf("\n\n");
	    	system("pause");
	    	system("cls");
			displayMenu();
        	printf("����������ѡ��");
        	scanf("%d", &choice);       
			c=getchar();
			while(getchar()!='\n');
			switch (choice) {
            case 1:
			    printf("\n\n");
                struct LinkNode *header=Init_LinkList();
                break;
            case 2:
                Foreach_LinkList(header);
                printf("\n\n");
	  			printf("�������²�������ݵĺ�һ������ֵ:\n");
   				scanf("%d",&oldval); 	
    			printf("�������²��������:\n");
    			scanf("%d",&newval);
				InsertByValue_LinkList(header,oldval,newval);
				printf("�µ�����Ϊ:\n");
				Foreach_LinkList(header);
                break;
            case 3:
            	printf("������Ϊ:\n");
                Foreach_LinkList(header);
                break;
            case 4:
            	printf("ԭ����Ϊ:\n");
                Foreach_LinkList(header);
                printf("\n\n");
				printf("������Ҫɾ���Ľ��:\n");
    			scanf("%d",&delValue);
    			printf("\n\n");
				RemoveByValue_LinkList(header,delValue);
				printf("ɾ����Ľ��Ϊ:\n");
				Foreach_LinkList(header);
                break;
            case 5:
            	Clear_LinkList(header);                
                break;
            case 6:    
                exit(0);
                break;
            default:
                printf("��Ч��ѡ�");
                system("pause");
                system("cls");
        }
	}
	
	system("pause");
	return 0;
}
